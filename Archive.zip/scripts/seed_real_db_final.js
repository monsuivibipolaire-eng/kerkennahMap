const { createClient } = require('@supabase/supabase-js');
const admin = require('firebase-admin');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

// --- CONFIGURATION (A REMPLIR) ---
const SUPABASE_URL = 'https://bcuxfuqgwoqyammgmpjw.supabase.co'; 
const SUPABASE_KEY = 'sb_secret_GnRXdBMwhJqpO4LZGKfwKg_HbVpIYjh';
const BUCKET_NAME = 'places-images';

const serviceAccountPath = path.join(__dirname, 'serviceAccountKey.json');
if (!fs.existsSync(serviceAccountPath)) { console.error("❌ Manque serviceAccountKey.json"); process.exit(1); }
const serviceAccount = require(serviceAccountPath);
admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });
const db = admin.firestore();
const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

// --- BANQUE D'IMAGES (Unsplash Stable) ---
const imgBank = {
  hopital: ["https://images.unsplash.com/photo-1587351021759-3e566b9af6f2?w=600", "https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=600"],
  pharmacie: ["https://images.unsplash.com/photo-1585435557343-3b092031a831?w=600", "https://images.unsplash.com/photo-1631549916768-4119b2e5f926?w=600"],
  ecole: ["https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=600", "https://images.unsplash.com/photo-1580582932707-520aed937b7b?w=600"],
  police: ["https://images.unsplash.com/photo-1455382054916-9c94e985343d?w=600", "https://images.unsplash.com/photo-1543262458-a49129299804?w=600"],
  poste: ["https://images.unsplash.com/photo-1579621970563-ebec7560eb3e?w=600", "https://images.unsplash.com/photo-1622151834677-70f982c9adef?w=600"],
  mosquee: ["https://images.unsplash.com/photo-1584551246679-0daf3d275d0f?w=600", "https://images.unsplash.com/photo-1542042956712-cdb2a4b85a1a?w=600"],
  boulangerie: ["https://images.unsplash.com/photo-1509440159596-0249088772ff?w=600", "https://images.unsplash.com/photo-1555507036-ab1f4038808a?w=600"],
  poissonnerie: ["https://images.unsplash.com/photo-1534447677768-be436bb09401?w=600", "https://images.unsplash.com/photo-1625943553852-781c6dd46faa?w=600"],
  magasin: ["https://images.unsplash.com/photo-1604719312566-8912e9227c6a?w=600", "https://images.unsplash.com/photo-1578916171728-46686eac8d58?w=600"],
  hotel: ["https://images.unsplash.com/photo-1566073771259-6a8506099945?w=600", "https://images.unsplash.com/photo-1496417263034-38ec4f0d665a?w=600"],
  restaurant: ["https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=600", "https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?w=600"],
  cafe: ["https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=600", "https://images.unsplash.com/photo-1511081692775-05d0f180a065?w=600"],
  port: ["https://images.unsplash.com/photo-1520255870067-5e9723041f31?w=600", "https://images.unsplash.com/photo-1505159940484-eb2b9f2588e2?w=600"]
};

function getImages(cats) {
  const c = cats[0].toLowerCase();
  let k = 'magasin';
  if (c.includes('santé') || c.includes('hôpital')) k = 'hopital';
  else if (c.includes('pharmacie')) k = 'pharmacie';
  else if (c.includes('école') || c.includes('lycée')) k = 'ecole';
  else if (c.includes('poste') || c.includes('mairie')) k = 'poste';
  else if (c.includes('police')) k = 'police';
  else if (c.includes('mosquée')) k = 'mosquee';
  else if (c.includes('boulangerie')) k = 'boulangerie';
  else if (c.includes('poisson')) k = 'poissonnerie';
  else if (c.includes('hôtel')) k = 'hotel';
  else if (c.includes('restaurant')) k = 'restaurant';
  else if (c.includes('café')) k = 'cafe';
  else if (c.includes('port')) k = 'port';
  return imgBank[k];
}

// --- DONNÉES RÉELLES (Recherche Web) ---
const realPlaces = [
  // SANTÉ (Réel)
  { name: "Hôpital Régional de Kerkennah (Salim)", desc: "Principal établissement de santé (Urgences).", lat: 34.7155, lng: 11.1985, cats: ["Santé", "Hôpital"] },
  { name: "Pharmacie Karray", desc: "Pharmacie à Remla Centre.", lat: 34.7135, lng: 11.1955, cats: ["Santé", "Pharmacie"] },
  { name: "Pharmacie Ben Messaoud", desc: "Pharmacie à El Attaya.", lat: 34.7460, lng: 11.2805, cats: ["Santé", "Pharmacie"] },
  { name: "Centre de Santé de Base Mellita", desc: "Dispensaire local.", lat: 34.6810, lng: 11.0820, cats: ["Santé"] },

  // ÉDUCATION (Réel)
  { name: "Lycée Farhat Hached", desc: "Le grand lycée de l'île.", lat: 34.7100, lng: 11.1900, cats: ["École", "Lycée"] },
  { name: "Collège Ibn Charaf (Remla)", desc: "Collège principal.", lat: 34.7120, lng: 11.1920, cats: ["École", "Collège"] },
  { name: "École Primaire Cité Echellal", desc: "École primaire.", lat: 34.7180, lng: 11.2050, cats: ["École"] },
  { name: "Collège de Mellita", desc: "Collège mixte.", lat: 34.6790, lng: 11.0780, cats: ["École", "Collège"] },

  // ADMINISTRATION & SÉCURITÉ (Réel)
  { name: "Poste Tunisienne Remla", desc: "Bureau central.", lat: 34.7140, lng: 11.1960, cats: ["Administration", "Poste"] },
  { name: "Municipalité de Kerkennah", desc: "Hôtel de Ville (Baladiya).", lat: 34.7130, lng: 11.1970, cats: ["Administration", "Mairie"] },
  { name: "Poste de Police Remla", desc: "Sûreté Nationale.", lat: 34.7155, lng: 11.1990, cats: ["Administration", "Police"] },
  { name: "Garde Nationale Maritime (Sidi Youssef)", desc: "Contrôle du port.", lat: 34.6540, lng: 10.9990, cats: ["Administration", "Police"] },
  { name: "Recette des Finances", desc: "Administration fiscale.", lat: 34.7132, lng: 11.1940, cats: ["Administration"] },

  // COMMERCES & SERVICES (Réel)
  { name: "Marché Central de Remla", desc: "Fruits, légumes et poissons.", lat: 34.7138, lng: 11.1945, cats: ["Commerce", "Poissonnerie"] },
  { name: "Magasin Général (MG)", desc: "Supermarché et point de vente agréé.", lat: 34.7125, lng: 11.1940, cats: ["Commerce", "Magasin", "Alcool"] },
  { name: "Boulangerie Moderne", desc: "Pain et pâtisseries.", lat: 34.7132, lng: 11.1952, cats: ["Commerce", "Boulangerie"] },
  { name: "Station Service Agil", desc: "Carburant (Remla).", lat: 34.7160, lng: 11.2000, cats: ["Commerce", "Station"] },
  { name: "Station Shell", desc: "Carburant (Sortie Sidi Youssef).", lat: 34.6600, lng: 11.0100, cats: ["Commerce", "Station"] },

  // CULTE (Réel)
  { name: "Mosquée Echemek", desc: "Mosquée historique.", lat: 34.7200, lng: 11.2100, cats: ["Culture", "Mosquée"] },
  { name: "Grande Mosquée Remla", desc: "Prière du vendredi.", lat: 34.7145, lng: 11.1950, cats: ["Culture", "Mosquée"] },
  { name: "Mosquée El Attaya", desc: "Sur le port.", lat: 34.7440, lng: 11.2790, cats: ["Culture", "Mosquée"] },

  // HÔTELS & MAISONS D'HÔTES (Réel)
  { name: "Grand Hôtel Kerkennah", desc: "Hôtel 3 étoiles pieds dans l'eau.", lat: 34.7065, lng: 11.1520, cats: ["Hôtel"] },
  { name: "Hôtel Cercina", desc: "Bungalows et restaurant plage.", lat: 34.7040, lng: 11.1480, cats: ["Hôtel"] },
  { name: "Résidence Club Kerkennah", desc: "Appartements touristiques.", lat: 34.7030, lng: 11.1450, cats: ["Hôtel"] },
  { name: "Dar El Fehri", desc: "Maison d'hôtes traditionnelle.", lat: 34.7260, lng: 11.2490, cats: ["Hôtel", "Maison d'hôtes"] },
  { name: "Manarat Kerkennah", desc: "Hôtel moderne.", lat: 34.7150, lng: 11.2050, cats: ["Hôtel"] },

  // RESTAURANTS & CAFÉS (Réel)
  { name: "Restaurant Le Pêcheur (Sta Ali)", desc: "Le spécialiste du poisson grillé.", lat: 34.7455, lng: 11.2810, cats: ["Restaurant"] },
  { name: "Restaurant La Sirène", desc: "Vue panoramique à Remla.", lat: 34.7140, lng: 11.1960, cats: ["Restaurant"] },
  { name: "Restaurant El Jazira", desc: "Cuisine populaire.", lat: 34.7125, lng: 11.1940, cats: ["Restaurant"] },
  { name: "Café des Palmiers", desc: "Le rendez-vous local.", lat: 34.7135, lng: 11.1945, cats: ["Café"] },
  { name: "Café de la Corniche", desc: "Vue mer à Sidi Fredj.", lat: 34.7055, lng: 11.1505, cats: ["Café"] },
  { name: "Fast Food Prince", desc: "Restauration rapide.", lat: 34.7130, lng: 11.1955, cats: ["Restaurant", "Snack"] },

  // PORTS & NATURE
  { name: "Port Sidi Youssef", desc: "Gare maritime.", lat: 34.6542, lng: 10.9987, cats: ["Transport", "Port"] },
  { name: "Port El Attaya", desc: "Port de pêcheurs.", lat: 34.7450, lng: 11.2800, cats: ["Pêche", "Port"] },
  { name: "Port Kraten", desc: "Port au nord de l'île.", lat: 34.7550, lng: 11.2900, cats: ["Pêche", "Port"] },
  { name: "Plage Sidi Founkhal", desc: "Plage sauvage magnifique.", lat: 34.7650, lng: 11.2950, cats: ["Plage", "Nature"] }
];

async function run() {
  console.log(\`🚀 Injection de \${realPlaces.length} lieux réels avec upload Supabase...\`);
  
  for (const p of realPlaces) {
    const urls = getImages(p.cats);
    const uploaded = [];

    if (!SUPABASE_URL.includes('votre-projet')) {
      process.stdout.write(\`Traitement: \${p.name} \`);
      for (const u of urls) {
        try {
          const res = await axios.get(u, { responseType: 'arraybuffer' });
          const fname = \`real_\${Date.now()}_\${Math.floor(Math.random()*10000)}.jpg\`;
          const { error } = await supabase.storage.from(BUCKET_NAME).upload(fname, res.data, { contentType: 'image/jpeg' });
          if (!error) {
             const { data } = supabase.storage.from(BUCKET_NAME).getPublicUrl(fname);
             uploaded.push(data.publicUrl);
             process.stdout.write(".");
          }
        } catch (e) { process.stdout.write("x"); }
      }
      console.log(" OK");
    } else { uploaded.push(...urls); }

    await db.collection('places').add({
      name: p.name, description: p.desc, latitude: p.lat, longitude: p.lng,
      categories: p.cats, status: 'approved', images: uploaded,
      createdAt: new Date(), createdBy: 'real_seeder'
    });
  }
  console.log("🎉 Terminé !");
}
run();
