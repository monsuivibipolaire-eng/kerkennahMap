
const { createClient } = require('@supabase/supabase-js');
const admin = require('firebase-admin');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

// =============================================================================
// 1. CONFIGURATION (A REMPLIR)
// =============================================================================
const SUPABASE_URL = 'https://bcuxfuqgwoqyammgmpjw.supabase.co'; 
const SUPABASE_KEY = 'sb_secret_GnRXdBMwhJqpO4LZGKfwKg_HbVpIYjh';
const BUCKET_NAME = 'places-images';

const serviceAccountPath = path.join(__dirname, 'serviceAccountKey.json');
if (!fs.existsSync(serviceAccountPath)) {
  console.error("❌ Manque serviceAccountKey.json"); process.exit(1);
}
const serviceAccount = require(serviceAccountPath);
admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });
const db = admin.firestore();
const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

// =============================================================================
// 2. DONNÉES (IMAGES UNSPLASH GARANTIES 100% FONCTIONNELLES)
// =============================================================================

// Banque d'images thématiques fiables
const imgs = {
  fort: "https://images.unsplash.com/photo-1599661046289-e31897846e41?w=800&q=80", // Ruines / Fort
  museum: "https://images.unsplash.com/photo-1518998053901-5348d3969dc5?w=800&q=80", // Musée / Tradition
  ruins: "https://images.unsplash.com/photo-1565881606991-789a8d579339?w=800&q=80", // Ruines romaines
  ferry: "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=800&q=80", // Port / Ferry
  city: "https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?w=800&q=80", // Ville / Rue
  fishing: "https://images.unsplash.com/photo-1520255870067-5e9723041f31?w=800&q=80", // Bateaux pêche
  village: "https://images.unsplash.com/photo-1444723121867-f69184bdbee7?w=800&q=80", // Village
  fish_food: "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=800&q=80", // Poisson
  restaurant: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80", // Terrasse resto
  couscous: "https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?w=800&q=80", // Plat traditionnel
  hotel_resort: "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800&q=80", // Grand Hotel
  bungalow: "https://images.unsplash.com/photo-1496417263034-38ec4f0d665a?w=800&q=80", // Bungalow
  beach: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&q=80", // Plage
  nature: "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=800&q=80", // Sauvage
  birds: "https://images.unsplash.com/photo-1452570053594-1b985d6ea890?w=800&q=80", // Oiseaux
  cafe: "https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=800&q=80", // Café
  shop: "https://images.unsplash.com/photo-1578916171728-46686eac8d58?w=800&q=80" // Épicerie
};

const places = [
  // --- CULTURE ---
  { name: "Borj El Hissar", desc: "Fort historique hispano-turc.", lat: 34.7089, lng: 11.1644, cats: ["Histoire", "Ruines"], img: imgs.fort },
  { name: "Musée du Patrimoine (Dar El Fehri)", desc: "Musée traditionnel.", lat: 34.7255, lng: 11.2485, cats: ["Culture", "Musée"], img: imgs.museum },
  { name: "Site Archéologique de Cercina", desc: "Ruines antiques.", lat: 34.6900, lng: 11.1200, cats: ["Histoire", "Ruines"], img: imgs.ruins },

  // --- PORTS & VILLES ---
  { name: "Port de Sidi Youssef", desc: "Arrivée des ferrys.", lat: 34.6542, lng: 10.9987, cats: ["Transport", "Port"], img: imgs.ferry },
  { name: "Remla Centre", desc: "Capitale administrative.", lat: 34.7130, lng: 11.1950, cats: ["Ville"], img: imgs.city },
  { name: "Port El Attaya", desc: "Village de pêcheurs.", lat: 34.7450, lng: 11.2800, cats: ["Pêche", "Port"], img: imgs.fishing },
  { name: "Mellita", desc: "Village historique.", lat: 34.6800, lng: 11.0800, cats: ["Ville"], img: imgs.village },

  // --- RESTAURANTS ---
  { name: "Restaurant Le Pêcheur (Sta Ali)", desc: "Spécialité poissons grillés.", lat: 34.7455, lng: 11.2810, cats: ["Restaurant"], img: imgs.fish_food },
  { name: "Restaurant La Sirène", desc: "Vue mer à Remla.", lat: 34.7140, lng: 11.1960, cats: ["Restaurant"], img: imgs.restaurant },
  { name: "Restaurant Najet", desc: "Cuisine tunisienne authentique.", lat: 34.7460, lng: 11.2790, cats: ["Restaurant"], img: imgs.couscous },
  { name: "Snack du Port", desc: "Sandwichs rapides.", lat: 34.6550, lng: 11.0000, cats: ["Restaurant", "Snack"], img: imgs.restaurant },

  // --- HÔTELS ---
  { name: "Grand Hôtel Kerkennah", desc: "Hôtel pieds dans l'eau.", lat: 34.7065, lng: 11.1520, cats: ["Hôtel"], img: imgs.hotel_resort },
  { name: "Hôtel Cercina", desc: "Bungalows charmants.", lat: 34.7040, lng: 11.1480, cats: ["Hôtel"], img: imgs.bungalow },
  { name: "Résidence Club", desc: "Appartements avec piscine.", lat: 34.7030, lng: 11.1450, cats: ["Hôtel"], img: imgs.hotel_resort },

  // --- PLAGES & NATURE ---
  { name: "Plage Sidi Fredj", desc: "La plage populaire.", lat: 34.7050, lng: 11.1500, cats: ["Plage"], img: imgs.beach },
  { name: "Pointe de Gremdi", desc: "Zone sauvage.", lat: 34.7600, lng: 11.3000, cats: ["Nature"], img: imgs.nature },
  { name: "Sebkha de Mellita", desc: "Flamants roses.", lat: 34.6700, lng: 11.0900, cats: ["Nature"], img: imgs.birds }
];

// --- REMPLISSAGE AUTOMATIQUE ---
const zones = [
  { n: "Remla", lat: 34.713, lng: 11.195 },
  { n: "El Attaya", lat: 34.745, lng: 11.280 },
  { n: "Sidi Fredj", lat: 34.705, lng: 11.150 },
  { n: "Mellita", lat: 34.680, lng: 11.080 }
];

const extras = [
  { type: "Café", names: ["Café des Amis", "Café Central", "Salon de Thé"], img: imgs.cafe },
  { type: "Commerce", names: ["Épicerie", "Boulangerie", "Kiosque"], img: imgs.shop },
  { type: "Plage", names: ["Crique", "Accès Mer"], img: imgs.beach }
];

for (const z of zones) {
  for (let i = 0; i < 20; i++) {
    const ex = extras[Math.floor(Math.random() * extras.length)];
    places.push({
      name: `${ex.names[Math.floor(Math.random()*ex.names.length)]} ${i+1}`,
      desc: `Lieu situé à ${z.n}.`,
      lat: z.lat + (Math.random() - 0.5) * 0.02,
      lng: z.lng + (Math.random() - 0.5) * 0.02,
      cats: [ex.type],
      img: ex.img
    });
  }
}

async function run() {
  console.log(`🚀 Démarrage Injection Stable (${places.length} lieux)...`);
  for (const p of places) {
    let publicUrl = "";
    if (p.img && !SUPABASE_URL.includes('votre-projet')) {
      try {
        console.log(`📥 DL: ${p.name}`);
        const res = await axios.get(p.img, { responseType: 'arraybuffer' });
        const fileName = `seed_${Date.now()}_${Math.floor(Math.random()*1000)}.jpg`;
        const { error } = await supabase.storage.from(BUCKET_NAME).upload(fileName, res.data, { contentType: 'image/jpeg' });
        if (!error) {
           const { data } = supabase.storage.from(BUCKET_NAME).getPublicUrl(fileName);
           publicUrl = data.publicUrl;
           console.log("✅ Upload Supabase OK");
        }
      } catch (e) {
        console.log("⚠️ Erreur upload, utilisation URL Unsplash.");
        publicUrl = p.img;
      }
    } else { publicUrl = p.img; }

    await db.collection('places').add({
      name: p.name, description: p.desc, latitude: p.lat, longitude: p.lng,
      categories: p.cats, status: 'approved', images: [publicUrl],
      createdAt: new Date(), createdBy: 'final_seeder'
    });
  }
  console.log("🎉 FINI !");
}

run();
