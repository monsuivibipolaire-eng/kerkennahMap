import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { Observable, of, firstValueFrom } from 'rxjs';

import { PlacesService } from '../../../../core/services/places.service';
import { Place } from '../../../../core/models/place.model';
import { AuthService } from '../../../../core/services/auth.service';

@Component({
  selector: 'app-admin-list',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './admin-list.component.html',
  styles: [`
    .card { @apply bg-white rounded-lg shadow p-6 mb-4; }
    .btn { @apply px-3 py-2 rounded text-sm font-semibold transition; }
    .btn-approve { @apply bg-green-600 text-white hover:bg-green-700; }
    .btn-reject { @apply bg-red-600 text-white hover:bg-red-700; }
    .badge { @apply inline-block text-xs px-2 py-1 rounded-full; }
  `]
})
export class AdminListComponent implements OnInit {
  private placesService = inject(PlacesService);
  private authService = inject(AuthService);

  // Pour admins : lieux en attente
  pendingPlaces$: Observable<Place[]> = of([]);

  // Pour non-admins : leurs propres lieux
  userPlaces$: Observable<Place[]> = of([]);

  isAdmin = false;
  currentUserId: string | null = null;

  isProcessingId: string | null = null;
  message = '';

  ngOnInit(): void {
    this.authService.user$.subscribe(user => {
      if (!user) {
        this.isAdmin = false;
        this.currentUserId = null;
        this.pendingPlaces$ = of([]);
        this.userPlaces$ = of([]);
        return;
      }

      const roles = (user as any)?.roles;
      const uid = (user as any)?.uid || (user as any)?.id || null;

      this.currentUserId = uid;
      this.isAdmin = Array.isArray(roles) && roles.includes('admin');

      if (this.isAdmin) {
        // 🛡 Admin : voit les lieux en attente
        this.pendingPlaces$ = this.placesService.getPendingPlaces();
        this.userPlaces$ = of([]);
      } else if (uid) {
        // 👤 Utilisateur normal : voit SES lieux ajoutés
        this.userPlaces$ = this.placesService.getPlacesByUser(uid);
        this.pendingPlaces$ = of([]);
      }
    });
  }

  // ✅ Valider un lieu (admin uniquement)
  async approve(place: Place) {
    if (!place.id) return;

    this.isProcessingId = place.id;
    this.message = '';

    try {
      const admin = await firstValueFrom(this.authService.user$);
      const adminId =
        (admin as any)?.uid ||
        (admin as any)?.id ||
        null;

      if (!this.isAdmin || !adminId) {
        this.message = '❌ Action réservée aux administrateurs.';
        this.isProcessingId = null;
        return;
      }

      await this.placesService.approvePlace(place.id, adminId);
      this.message = `✅ Lieu "${place.name}" approuvé.`;
    } catch (err) {
      console.error(err);
      this.message = `❌ Erreur lors de la validation de "${place.name}".`;
    } finally {
      this.isProcessingId = null;
    }
  }

  // ❌ Rejeter un lieu (admin uniquement)
  async reject(place: Place) {
    if (!place.id) return;

    const confirmReject = window.confirm(
      `Êtes-vous sûr de vouloir rejeter le lieu "${place.name}" ?`
    );
    if (!confirmReject) return;

    this.isProcessingId = place.id;
    this.message = '';

    try {
      if (!this.isAdmin) {
        this.message = '❌ Action réservée aux administrateurs.';
        this.isProcessingId = null;
        return;
      }

      await this.placesService.rejectPlace(place.id);
      this.message = `✅ Lieu "${place.name}" rejeté.`;
    } catch (err) {
      console.error(err);
      this.message = `❌ Erreur lors du rejet de "${place.name}".`;
    } finally {
      this.isProcessingId = null;
    }
  }
}
