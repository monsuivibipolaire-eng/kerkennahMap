import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, NgForm } from '@angular/forms';
import { LeafletModule } from '@bluehalo/ngx-leaflet';
import * as L from 'leaflet';
import { Router } from '@angular/router';
import { PlacesService } from '../../../../core/services/places.service';
import { SupabaseImageService } from '../../../../core/services/supabase-image.service';
import { AuthService } from '../../../../core/services/auth.service';
import { Place } from '../../../../core/models/place.model';
import { firstValueFrom } from 'rxjs';

@Component({
  selector: 'app-add-place',
  standalone: true,
  imports: [CommonModule, FormsModule, LeafletModule],
  templateUrl: './add-place.component.html',
  styleUrls: ['./add-place.component.css']
})
export class AddPlaceComponent implements OnInit {
  // Modèle de base du formulaire
  model: Partial<Place> = {
    name: '',
    description: '',
    latitude: 34.71,
    longitude: 11.15,
    categories: [],
    images: [],
    videos: [],
    status: 'pending'
  };

  categoriesList: string[] = [
    'Restaurant',
    'Fruits de mer',
    'Café',
    'Fast-food',
    'Pizzeria',
    'Boulangerie',
    'Glacier',
    'Bar',
    'Hôtel',
    'Maison d’hôtes',
    'Camping',
    'Plage',
    'Parc',
    'Jardin',
    'Randonnée',
    'Musée',
    'Monument',
    'Site historique',
    'Site archéologique',
    'Centre commercial',
    'Marché',
    'Souk',
    'Commerce',
    'Spa',
    'Bien-être',
    'Activités nautiques',
    'Pêche',
    'Famille',
    'Romantique',
    'Vue panoramique'
  ];

  isSubmitting = false;
  uploadingImages = false;
  uploadingVideos = false;
  errorMessage = '';
  successMessage = '';

  mapOptions: L.MapOptions = {
    layers: [
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 18
      })
    ],
    zoom: 10,
    center: L.latLng(34.71, 11.15)
  };

  marker: L.Marker | null = null;

  constructor(
    private placesService: PlacesService,
    private imageService: SupabaseImageService,
    private auth: AuthService,
    private router: Router
  ) {
    const iconRetinaUrl =
      'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png';
    const iconUrl =
      'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png';
    const shadowUrl =
      'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png';

    (L.Marker.prototype as any).options.icon = L.icon({
      iconRetinaUrl,
      iconUrl,
      shadowUrl,
      iconSize: [25, 41],
      iconAnchor: [12, 41],
      popupAnchor: [1, -34],
      tooltipAnchor: [16, -28],
      shadowSize: [41, 41]
    });
  }

  ngOnInit(): void {
    this.updateMarker(this.model.latitude!, this.model.longitude!);
  }

  onMapReady(map: L.Map) {
    map.on('click', (e: L.LeafletMouseEvent) => {
      this.model.latitude = e.latlng.lat;
      this.model.longitude = e.latlng.lng;
      this.updateMarker(e.latlng.lat, e.latlng.lng);
    });
  }

  updateMarker(lat: number, lng: number) {
    if (this.marker) {
      this.marker.setLatLng([lat, lng]);
    } else {
      this.marker = L.marker([lat, lng]);
    }
  }

  get mapLayers(): L.Layer[] {
    return this.marker ? [this.marker] : [];
  }

  // Catégories (checkbox)
  toggleCategory(cat: string, event: Event) {
    const input = event.target as HTMLInputElement;
    const checked = input.checked;

    if (!this.model.categories) {
      this.model.categories = [];
    }

    if (checked) {
      if (!this.model.categories.includes(cat)) {
        this.model.categories.push(cat);
      }
    } else {
      this.model.categories = this.model.categories.filter(c => c !== cat);
    }
  }

  // Upload d'IMAGES
  async onImagesSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (!input.files || input.files.length === 0) return;

    const files = Array.from(input.files);
    this.uploadingImages = true;
    this.errorMessage = '';

    try {
      if (!this.model.images) this.model.images = [];

      for (const file of files) {
        const safeName = file.name.replace(/[^a-zA-Z0-9.]/g, '_');
        const fileName = `${Date.now()}_${safeName}`;
        const path = `images/${fileName}`;
        const url = await this.imageService.uploadImage(file, path);
        if (url) this.model.images.push(url);
      }

      input.value = '';
    } catch (err: any) {
      console.error('Upload images failed', err);
      this.errorMessage =
        "Erreur lors de l'upload des images : " +
        (err?.message || 'Vérifiez votre configuration Supabase');
    } finally {
      this.uploadingImages = false;
    }
  }

  // Upload de VIDEOS
  async onVideosSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (!input.files || input.files.length === 0) return;

    const files = Array.from(input.files);
    this.uploadingVideos = true;
    this.errorMessage = '';

    try {
      if (!this.model.videos) this.model.videos = [];

      for (const file of files) {
        const safeName = file.name.replace(/[^a-zA-Z0-9.]/g, '_');
        const fileName = `${Date.now()}_${safeName}`;
        const path = `videos/${fileName}`;
        const url = await this.imageService.uploadImage(file, path);
        if (url) this.model.videos.push(url);
      }

      input.value = '';
    } catch (err: any) {
      console.error('Upload videos failed', err);
      this.errorMessage =
        "Erreur lors de l'upload des vidéos : " +
        (err?.message || 'Vérifiez votre configuration Supabase');
    } finally {
      this.uploadingVideos = false;
    }
  }

  removeImage(url: string) {
    if (!this.model.images) return;
    this.model.images = this.model.images.filter(i => i !== url);
  }

  removeVideo(url: string) {
    if (!this.model.videos) return;
    this.model.videos = this.model.videos.filter(v => v !== url);
  }

  // Soumission du formulaire
  async onSubmit(form: NgForm) {
    if (form.invalid || this.isSubmitting) return;

    this.isSubmitting = true;
    this.errorMessage = '';
    this.successMessage = '';

    try {
      const user = await firstValueFrom(this.auth.user$);
      if (!user) {
        this.errorMessage = 'Vous devez être connecté.';
        this.isSubmitting = false;
        return;
      }

      const roles = (user as any).roles || [];
      const isAdmin =
        Array.isArray(roles) && roles.includes('admin');

      // ✅ Si admin -> approved, sinon -> pending
      const status: 'pending' | 'approved' | 'rejected' =
        isAdmin ? 'approved' : 'pending';

      const placeData: Place = {
        name: this.model.name!.trim(),
        description: this.model.description!.trim(),
        latitude: this.model.latitude!,
        longitude: this.model.longitude!,
        categories: this.model.categories || [],
        images: this.model.images || [],
        videos: this.model.videos || [],
        status,
        createdBy: (user as any).uid || (user as any).id || 'unknown',
        createdAt: new Date()
      };

      await this.placesService.addPlace(placeData);

      this.successMessage = isAdmin
        ? 'Lieu ajouté et publié avec succès !'
        : 'Lieu ajouté ! En attente de validation par un administrateur.';

      form.resetForm({
        latitude: 34.71,
        longitude: 11.15,
        categories: [],
        images: [],
        videos: []
      });
      this.model = {
        latitude: 34.71,
        longitude: 11.15,
        categories: [],
        images: [],
        videos: [],
        status: 'pending'
      };
      this.updateMarker(34.71, 11.15);

      setTimeout(() => this.router.navigate(['/']), 1500);
    } catch (err) {
      console.error(err);
      this.errorMessage = "Erreur lors de l'enregistrement.";
    } finally {
      this.isSubmitting = false;
    }
  }
}
