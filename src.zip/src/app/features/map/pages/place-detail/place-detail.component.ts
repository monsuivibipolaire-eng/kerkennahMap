import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterModule, Router } from '@angular/router';
import { LeafletModule } from '@bluehalo/ngx-leaflet';
import * as L from 'leaflet';
import { Observable, of } from 'rxjs';
import { switchMap, tap, map } from 'rxjs/operators';
import { FormsModule } from '@angular/forms';

import { PlacesService } from '../../../../core/services/places.service';
import { Place } from '../../../../core/models/place.model';
import { AuthService } from '../../../../core/services/auth.service';
import { SupabaseImageService } from '../../../../core/services/supabase-image.service';

interface PlaceComment {
  userName: string;
  rating: number;
  comment: string;
  createdAt: Date;
}

@Component({
  selector: 'app-place-detail',
  standalone: true,
  imports: [CommonModule, RouterModule, LeafletModule, FormsModule],
  templateUrl: './place-detail.component.html',
  styleUrls: ['./place-detail.component.css']
})
export class PlaceDetailComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private placesService = inject(PlacesService);
  private authService = inject(AuthService);
  private supabaseImageService = inject(SupabaseImageService);

  // Place affichée
  place$: Observable<Place | undefined> = of(undefined);

  // Admin / connexion
  isAdmin = false;
  isLoggedIn = false;
  currentUserName: string | null = null;

  // Modal édition
  showEditModal = false;
  editingPlace: Place | null = null;

  // Upload états
  uploadingImages = false;
  uploadingVideos = false;
  uploadError: string | null = null;

  // Galerie plein écran
  showMediaViewer = false;
  mediaViewerItems: { type: 'image' | 'video'; src: string }[] = [];
  mediaViewerIndex = 0;

  // Avis / commentaires
  comments: PlaceComment[] = [];
  newCommentRating = 5;
  newCommentText = '';
  isSubmittingComment = false;

  // Liste de catégories disponibles
  availableCategories: string[] = [
    'Restaurant',
    'Fruits de mer',
    'Café',
    'Fast-food',
    'Pizzeria',
    'Boulangerie',
    'Glacier',
    'Bar',
    'Hôtel',
    'Hébergement',
    'Activité',
    'Culture',
    'Sport',
    'Shopping',
    'Autre'
  ];

  // Config Leaflet
  mapOptions: L.MapOptions = {
    layers: [
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 18
      })
    ],
    zoom: 14,
    center: L.latLng(34.71, 11.15)
  };

  mapLayers: L.Layer[] = [];

  constructor() {
    // Patch icônes Leaflet (pour éviter les problèmes de bundling)
    const iconRetinaUrl =
      'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png';
    const iconUrl = 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png';
    const shadowUrl =
      'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png';

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (L.Marker as any).prototype.options.icon = L.icon({
      iconRetinaUrl,
      iconUrl,
      shadowUrl,
      iconSize: [25, 41],
      iconAnchor: [12, 41],
      popupAnchor: [1, -34],
      shadowSize: [41, 41]
    });
  }

  ngOnInit(): void {
    // Gestion connexion / admin avec AuthService (façon "safe" via any)
    const anyAuth = this.authService as any;

    if (anyAuth.user$ && typeof anyAuth.user$.subscribe === 'function') {
      anyAuth.user$.subscribe((user: any) => {
        this.isLoggedIn = !!user;
        if (user) {
          this.currentUserName =
            user.fullName || user.name || user.email || 'Utilisateur';

          if (Array.isArray(user.roles)) {
            this.isAdmin = user.roles.includes('admin');
          }
        } else {
          this.currentUserName = null;
          this.isAdmin = false;
        }
      });
    } else if (anyAuth.isLoggedIn$ && typeof anyAuth.isLoggedIn$.subscribe === 'function') {
      anyAuth.isLoggedIn$.subscribe((logged: any) => {
        this.isLoggedIn = !!logged;
      });
    } else if (typeof anyAuth.isLoggedIn === 'boolean') {
      this.isLoggedIn = anyAuth.isLoggedIn;
    }

    // Récupérer la place & normaliser les dates
    this.place$ = this.route.paramMap.pipe(
      switchMap((params) => {
        const id = params.get('id');
        if (!id) {
          return of(undefined);
        }
        return this.placesService.getPlaceById(id);
      }),
      map((place: Place | undefined) =>
        place ? this.normalizePlaceDates(place) : undefined
      ),
      tap((place) => {
        if (place) {
          this.updateMap(place);
        }
      })
    );
  }

  /**
   * Convertit les champs de type Timestamp / string / number en Date
   * pour que le DatePipe Angular les accepte.
   */
  private normalizePlaceDates(place: Place): Place {
    const convert = (v: any): Date | undefined => {
      if (!v) return undefined;
      if (v instanceof Date) return v;
      // Firestore / Supabase Timestamp avec méthode toDate()
      if (typeof v.toDate === 'function') return v.toDate();
      // Objet { seconds, nanoseconds }
      if (typeof v.seconds === 'number') {
        return new Date(v.seconds * 1000);
      }
      // nombre (ms)
      if (typeof v === 'number') return new Date(v);
      // string parsable
      const parsed = new Date(v);
      if (!isNaN(parsed.getTime())) return parsed;
      return undefined;
    };

    return {
      ...place,
      createdAt: convert((place as any).createdAt) as any,
      updatedAt: convert((place as any).updatedAt) as any,
      validatedAt: convert((place as any).validatedAt) as any
    };
  }

  private updateMap(place: Place) {
    if (place.latitude && place.longitude) {
      this.mapOptions = {
        ...this.mapOptions,
        center: L.latLng(place.latitude, place.longitude)
      };

      this.mapLayers = [
        L.marker([place.latitude, place.longitude]).bindPopup(place.name)
      ];
    }
  }

  // -------- AVIS / COMMENTAIRES --------

  get averageRating(): number | null {
    if (!this.comments.length) {
      return null;
    }
    const sum = this.comments.reduce((acc, c) => acc + c.rating, 0);
    return Math.round((sum / this.comments.length) * 10) / 10;
  }

  submitComment(): void {
    if (!this.isLoggedIn) {
      return;
    }
    const text = this.newCommentText.trim();
    if (!text) {
      return;
    }

    this.isSubmittingComment = true;

    const newComment: PlaceComment = {
      userName: this.currentUserName || 'Utilisateur',
      rating: this.newCommentRating,
      comment: text,
      createdAt: new Date()
    };

    // Pour l’instant, stockage local uniquement (pas de backend)
    this.comments = [newComment, ...this.comments];

    this.newCommentText = '';
    this.newCommentRating = 5;
    this.isSubmittingComment = false;
  }

  // -------- MODAL ÉDITION --------

  openEditModal(place: Place) {
    this.uploadError = null;
    this.uploadingImages = false;
    this.uploadingVideos = false;

    // On clone la place pour ne pas modifier l'original tant que ce n'est pas sauvegardé
    this.editingPlace = {
      ...place,
      images: [...(place.images || [])],
      videos: [...(place.videos || [])],
      categories: [...(place.categories || [])]
    };
    this.showEditModal = true;
  }

  closeEditModal() {
    this.showEditModal = false;
    this.editingPlace = null;
    this.uploadError = null;
    this.uploadingImages = false;
    this.uploadingVideos = false;
  }

  // -------- CATEGORIES --------

  toggleCategory(category: string) {
    if (!this.editingPlace) return;

    const categories = this.editingPlace.categories || [];
    const index = categories.indexOf(category);
    if (index > -1) {
      categories.splice(index, 1);
    } else {
      categories.push(category);
    }
    this.editingPlace = {
      ...this.editingPlace,
      categories: [...categories]
    };
  }

  // -------- IMAGES --------

  async onImagesSelected(event: Event) {
    if (!this.editingPlace) return;

    const input = event.target as HTMLInputElement;
    if (!input.files || input.files.length === 0) return;

    const files = Array.from(input.files);

    this.uploadingImages = true;
    this.uploadError = null;

    try {
      const baseId = this.editingPlace.id || 'temp';
      const uploadPromises = files.map((file, index) =>
        this.supabaseImageService.uploadImage(
          file,
          `places/${baseId}/images/${Date.now()}-${index}-${file.name}`
        )
      );

      const results = await Promise.all(uploadPromises);
      const urls = results.filter((u): u is string => !!u);

      const existing = this.editingPlace.images || [];
      this.editingPlace = {
        ...this.editingPlace,
        images: [...existing, ...urls]
      };
    } catch (err) {
      console.error('Erreur upload images', err);
      this.uploadError = "Erreur lors de l'upload des images.";
    } finally {
      this.uploadingImages = false;
    }
  }

  removeImage(index: number) {
    if (!this.editingPlace) return;
    const images = [...(this.editingPlace.images || [])];
    images.splice(index, 1);
    this.editingPlace = {
      ...this.editingPlace,
      images
    };
  }

  // -------- VIDEOS --------

  async onVideosSelected(event: Event) {
    if (!this.editingPlace) return;

    const input = event.target as HTMLInputElement;
    if (!input.files || input.files.length === 0) return;

    const files = Array.from(input.files);

    this.uploadingVideos = true;
    this.uploadError = null;

    try {
      const baseId = this.editingPlace.id || 'temp';
      const uploadPromises = files.map((file, index) =>
        // On réutilise uploadImage pour les vidéos (Supabase se fiche du type)
        this.supabaseImageService.uploadImage(
          file,
          `places/${baseId}/videos/${Date.now()}-${index}-${file.name}`
        )
      );

      const results = await Promise.all(uploadPromises);
      const urls = results.filter((u): u is string => !!u);

      const existing = this.editingPlace.videos || [];
      this.editingPlace = {
        ...this.editingPlace,
        videos: [...existing, ...urls]
      };
    } catch (err) {
      console.error('Erreur upload vidéos', err);
      this.uploadError = "Erreur lors de l'upload des vidéos.";
    } finally {
      this.uploadingVideos = false;
    }
  }

  removeVideo(index: number) {
    if (!this.editingPlace) return;
    const videos = [...(this.editingPlace.videos || [])];
    videos.splice(index, 1);
    this.editingPlace = {
      ...this.editingPlace,
      videos
    };
  }

  // -------- SAUVEGARDE --------

  async savePlace() {
    if (!this.editingPlace || !this.editingPlace.id) return;

    const id = this.editingPlace.id;

    const payload: Partial<Place> = {
      ...this.editingPlace,
      updatedAt: new Date()
    };

    try {
      await this.placesService.updatePlace(id, payload);
      this.closeEditModal();

      // Recharger la place pour raffraîchir l'affichage
      this.place$ = this.placesService.getPlaceById(id).pipe(
        map((place) => (place ? this.normalizePlaceDates(place) : undefined)),
        tap((place) => {
          if (place) {
            this.updateMap(place);
          }
        })
      );
    } catch (err) {
      console.error('Erreur lors de la mise à jour du lieu', err);
      this.uploadError = 'Erreur lors de la sauvegarde du lieu.';
    }
  }

  // -------- SUPPRESSION --------

  async onDeletePlace(place: Place) {
    if (!this.isAdmin || !place.id) return;

    const ok = window.confirm(
      'Êtes-vous sûr de vouloir supprimer définitivement ce lieu ?'
    );
    if (!ok) return;

    try {
      await this.placesService.deletePlace(place.id);
      this.router.navigate(['/']);
    } catch (err) {
      console.error('Erreur lors de la suppression du lieu', err);
      alert('Erreur lors de la suppression du lieu.');
    }
  }

  // ---------- GALERIE PLEIN ÉCRAN (images + vidéos) ----------

  openMediaViewerFromImage(place: Place, imageIndex: number): void {
    const images = place.images ?? [];
    const videos = place.videos ?? [];

    this.mediaViewerItems = [
      ...images.map((src) => ({ type: 'image' as const, src })),
      ...videos.map((src) => ({ type: 'video' as const, src }))
    ];

    this.mediaViewerIndex = Math.min(
      Math.max(imageIndex, 0),
      this.mediaViewerItems.length - 1
    );
    this.showMediaViewer = this.mediaViewerItems.length > 0;
  }

  openMediaViewerFromVideo(place: Place, videoIndex: number): void {
    const images = place.images ?? [];
    const videos = place.videos ?? [];

    this.mediaViewerItems = [
      ...images.map((src) => ({ type: 'image' as const, src })),
      ...videos.map((src) => ({ type: 'video' as const, src }))
    ];

    const startIndex = images.length + videoIndex;
    this.mediaViewerIndex = Math.min(
      Math.max(startIndex, 0),
      this.mediaViewerItems.length - 1
    );
    this.showMediaViewer = this.mediaViewerItems.length > 0;
  }

  closeMediaViewer(): void {
    this.showMediaViewer = false;
  }

  nextMedia(): void {
    if (!this.mediaViewerItems.length) return;
    this.mediaViewerIndex =
      (this.mediaViewerIndex + 1) % this.mediaViewerItems.length;
  }

  prevMedia(): void {
    if (!this.mediaViewerItems.length) return;
    this.mediaViewerIndex =
      (this.mediaViewerIndex - 1 + this.mediaViewerItems.length) %
      this.mediaViewerItems.length;
  }

  get currentMedia():
    | { type: 'image' | 'video'; src: string }
    | null {
    if (!this.mediaViewerItems.length) return null;
    return this.mediaViewerItems[this.mediaViewerIndex];
  }
}
