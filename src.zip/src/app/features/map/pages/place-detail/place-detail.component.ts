import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterModule, Router } from '@angular/router';
import { LeafletModule } from '@bluehalo/ngx-leaflet';
import * as L from 'leaflet';
import { Observable, of } from 'rxjs';
import { switchMap, tap } from 'rxjs/operators';
import { FormsModule } from '@angular/forms';

import { PlacesService } from '../../../../core/services/places.service';
import { Place } from '../../../../core/models/place.model';
import { AuthService } from '../../../../core/services/auth.service';
import { SupabaseImageService } from '../../../../core/services/supabase-image.service';

@Component({
  selector: 'app-place-detail',
  standalone: true,
  imports: [CommonModule, LeafletModule, RouterModule, FormsModule],
  templateUrl: './place-detail.component.html',
  styleUrls: ['./place-detail.component.css']
})
export class PlaceDetailComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private placesService = inject(PlacesService);
  private authService = inject(AuthService);
  private supabaseImageService = inject(SupabaseImageService);

  // Place affichée
  place$: Observable<Place | undefined> = of(undefined);

  // Admin ?
  isAdmin = false;

  // Modal édition
  showEditModal = false;
  editingPlace: Place | null = null;

  // Upload états
  uploadingImages = false;
  uploadingVideos = false;
  uploadError: string | null = null;

  // Liste de catégories disponibles
  availableCategories: string[] = [
    'Restaurant',
    'Fruits de mer',
    'Café',
    'Fast-food',
    'Pizzeria',
    'Boulangerie',
    'Glacier',
    'Bar',
    'Hôtel',
    'Maison d’hôtes',
    'Camping',
    'Plage',
    'Parc',
    'Jardin',
    'Randonnée',
    'Musée',
    'Monument',
    'Site historique',
    'Site archéologique',
    'Centre commercial',
    'Marché',
    'Souk',
    'Commerce',
    'Spa',
    'Bien-être',
    'Activités nautiques',
    'Pêche',
    'Famille',
    'Romantique',
    'Vue panoramique'
  ];

  // Carte
  mapOptions: L.MapOptions = {
    layers: [
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 18
      })
    ],
    zoom: 14,
    center: L.latLng(34.71, 11.15)
  };

  mapLayers: L.Layer[] = [];

  constructor() {
    // Patch icônes Leaflet
    const iconRetinaUrl =
      'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png';
    const iconUrl =
      'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png';
    const shadowUrl =
      'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png';

    (L.Marker.prototype as any).options.icon = L.icon({
      iconRetinaUrl,
      iconUrl,
      shadowUrl,
      iconSize: [25, 41],
      iconAnchor: [12, 41],
      popupAnchor: [1, -34],
      tooltipAnchor: [16, -28],
      shadowSize: [41, 41]
    });
  }

  ngOnInit(): void {
    // Est-ce que l'utilisateur est admin ?
    this.authService.user$.subscribe(user => {
      const roles = (user as any)?.roles;
      this.isAdmin = Array.isArray(roles) && roles.includes('admin');
    });

    // Charger la place depuis l'URL
    this.place$ = this.route.paramMap.pipe(
      switchMap(params => {
        const id = params.get('id');
        if (id) {
          return this.placesService.getPlaceById(id);
        }
        return of(undefined);
      }),
      tap(place => {
        if (place) {
          this.updateMap(place);
        }
      })
    );
  }

  updateMap(place: Place) {
    this.mapOptions = {
      ...this.mapOptions,
      center: L.latLng(place.latitude, place.longitude)
    };

    this.mapLayers = [
      L.marker([place.latitude, place.longitude]).bindPopup(place.name)
    ];
  }

  // -------- MODAL ÉDITION --------

  openEditModal(place: Place) {
    this.uploadError = null;
    this.uploadingImages = false;
    this.uploadingVideos = false;

    // On clone la place pour ne pas modifier directement la référence du flux
    this.editingPlace = {
      ...place,
      categories: [...(place.categories || [])],
      images: [...(place.images || [])],
      videos: [...(place.videos || [])]
    };
    this.showEditModal = true;
  }

  closeEditModal() {
    this.showEditModal = false;
    this.editingPlace = null;
    this.uploadError = null;
    this.uploadingImages = false;
    this.uploadingVideos = false;
  }

  toggleCategory(cat: string, event: Event) {
    if (!this.editingPlace) return;
    const input = event.target as HTMLInputElement;
    const checked = input.checked;

    const current = this.editingPlace.categories || [];
    if (checked) {
      if (!current.includes(cat)) {
        this.editingPlace = {
          ...this.editingPlace,
          categories: [...current, cat]
        };
      }
    } else {
      this.editingPlace = {
        ...this.editingPlace,
        categories: current.filter(c => c !== cat)
      };
    }
  }

  // -------- IMAGES --------

  async onImagesSelected(event: Event) {
    if (!this.editingPlace) return;
    const input = event.target as HTMLInputElement;
    if (!input.files || input.files.length === 0) return;

    const files = Array.from(input.files);
    this.uploadingImages = true;
    this.uploadError = null;

    try {
      const newUrls: string[] = [];
      const idPart = this.editingPlace.id || 'temp';

      for (const file of files) {
        const safeName = file.name.replace(/\s+/g, '-').toLowerCase();
        const path = `images/${idPart}-${Date.now()}-${safeName}`;
        const url = await this.supabaseImageService.uploadImage(file, path);
        if (url) newUrls.push(url);
      }

      this.editingPlace = {
        ...this.editingPlace,
        images: [...(this.editingPlace.images || []), ...newUrls]
      };

      input.value = '';
    } catch (err) {
      console.error('Erreur upload images', err);
      this.uploadError = "Erreur lors de l'upload des images.";
    } finally {
      this.uploadingImages = false;
    }
  }

  removeExistingImage(url: string) {
    if (!this.editingPlace) return;
    this.editingPlace = {
      ...this.editingPlace,
      images: (this.editingPlace.images || []).filter(img => img !== url)
    };
  }

  // -------- VIDEOS --------

  async onVideosSelected(event: Event) {
    if (!this.editingPlace) return;
    const input = event.target as HTMLInputElement;
    if (!input.files || input.files.length === 0) return;

    const files = Array.from(input.files);
    this.uploadingVideos = true;
    this.uploadError = null;

    try {
      const newUrls: string[] = [];
      const idPart = this.editingPlace.id || 'temp';

      for (const file of files) {
        const safeName = file.name.replace(/\s+/g, '-').toLowerCase();
        const path = `videos/${idPart}-${Date.now()}-${safeName}`;
        const url = await this.supabaseImageService.uploadImage(file, path);
        if (url) newUrls.push(url);
      }

      this.editingPlace = {
        ...this.editingPlace,
        videos: [...(this.editingPlace.videos || []), ...newUrls]
      };

      input.value = '';
    } catch (err) {
      console.error('Erreur upload vidéos', err);
      this.uploadError = "Erreur lors de l'upload des vidéos.";
    } finally {
      this.uploadingVideos = false;
    }
  }

  removeExistingVideo(url: string) {
    if (!this.editingPlace) return;
    this.editingPlace = {
      ...this.editingPlace,
      videos: (this.editingPlace.videos || []).filter(v => v !== url)
    };
  }

  // -------- SAUVEGARDE --------

  async savePlace() {
    if (!this.editingPlace || !this.editingPlace.id) return;

    const id = this.editingPlace.id;
    const payload: Partial<Place> = {
      name: this.editingPlace.name,
      description: this.editingPlace.description,
      latitude: this.editingPlace.latitude,
      longitude: this.editingPlace.longitude,
      categories: this.editingPlace.categories || [],
      images: this.editingPlace.images || [],
      videos: this.editingPlace.videos || [],
      updatedAt: new Date()
    };

    try {
      await this.placesService.updatePlace(id, payload);
      this.closeEditModal();

      // Recharger la place pour raffraîchir l'affichage
      this.place$ = this.placesService.getPlaceById(id).pipe(
        tap(place => {
          if (place) {
            this.updateMap(place);
          }
        })
      );
    } catch (err) {
      console.error('Erreur lors de la mise à jour de la place', err);
    }
  }

  // -------- SUPPRESSION --------

  async onDeletePlace(place: Place) {
    if (!this.isAdmin || !place.id) return;

    const ok = window.confirm(
      'Êtes-vous sûr de vouloir supprimer définitivement ce lieu ?'
    );
    if (!ok) return;

    try {
      await this.placesService.deletePlace(place.id);
      this.router.navigate(['/']);
    } catch (err) {
      console.error('Erreur lors de la suppression du lieu', err);
      alert("Erreur lors de la suppression du lieu.");
    }
  }
}
