export interface Place {
  id?: string;
  name: string;
  description: string;
  latitude: number;
  longitude: number;
  categories: string[];
  images: string[];      // URLs des images
  videos?: string[];     // URLs des vidéos (optionnel)
  status: 'pending' | 'approved' | 'rejected';
  createdBy: string;     // UID ou ID de l'utilisateur ayant créé le lieu
  createdAt: Date | any; // compatibilité Timestamp Firestore
  updatedAt?: Date | any;
  validatedBy?: string;  // UID ou ID de l'admin qui a validé
  validatedAt?: Date | any;
}
