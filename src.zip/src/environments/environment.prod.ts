export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: 'AIzaSyA36WJbXgjRzOjLvU4WM6ZXp4CLWff-0-o',
    authDomain: 'kerkennahmap.firebaseapp.com',
    projectId: 'kerkennahmap',
    storageBucket: 'kerkennahmap.firebasestorage.app',
    messagingSenderId: '271484483702',
    appId: '1:271484483702:web:5557f410ceaacac2010757',
    measurementId: 'G-FXFDCLE25Q'
  },
  supabaseUrl: 'https://bcuxfuqgwoqyammgmpjw.supabase.co',
  supabaseKey: 'sb_secret_GnRXdBMwhJqpO4LZGKfwKg_HbVpIYjh'
};
